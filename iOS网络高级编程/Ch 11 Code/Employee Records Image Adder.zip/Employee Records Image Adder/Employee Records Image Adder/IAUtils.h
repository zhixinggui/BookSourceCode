//
//  IAUtils.h
//  Employee Records Image Adder
//
//  Copyright (c) 2012 John Szumski. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IAUtils : NSObject

+ (NSString*)encodeURL:(NSString *)string;

@end