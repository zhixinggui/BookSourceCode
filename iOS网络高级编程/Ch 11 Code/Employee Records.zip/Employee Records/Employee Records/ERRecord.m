//
//  ERRecord.m
//  Employee Records
//
//  Copyright (c) 2012 John Szumski. All rights reserved.
//

#import "ERRecord.h"

@implementation ERRecord

@synthesize employeeName, idNumber, salary, socialSecurityNumber, image;

@end