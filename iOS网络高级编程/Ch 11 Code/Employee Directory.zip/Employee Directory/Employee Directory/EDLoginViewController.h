//
//  EDLoginViewController.h
//  Employee Directory
//
//  Copyright (c) 2012 John Szumski. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EDLoginViewController : UITableViewController

@end