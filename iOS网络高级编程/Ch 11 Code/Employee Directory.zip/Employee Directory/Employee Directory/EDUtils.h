//
//  EDUtils.h
//  Employee Directory
//
//  Copyright (c) 2012 John Szumski. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EDUtils : NSObject

+ (NSDictionary*)dictionaryOfInstalledCompanionApps;

@end