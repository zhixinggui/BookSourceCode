//
//  Contact.m
//  RelationshipManager
//
//  Created by Nathan Jones on 4/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Contact.h"
#import "Note.h"


@implementation Contact

@dynamic firstName;
@dynamic lastName;
@dynamic company;
@dynamic emailAddress;
@dynamic phoneNumber;
@dynamic notes;

@end
