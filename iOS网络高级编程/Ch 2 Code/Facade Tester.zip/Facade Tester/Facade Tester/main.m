//
//  main.m
//  Facade Tester
//
//

#import <UIKit/UIKit.h>

#import "FTAppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([FTAppDelegate class]));
	}
}
