//
//  FTWeatherViewController.h
//  Facade Tester
//
//  Copyright (c) 2012 John Szumski. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FTWeatherViewController : UITableViewController

@end
