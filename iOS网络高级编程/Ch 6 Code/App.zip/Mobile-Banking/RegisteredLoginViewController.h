//
//  RegisteredLoginViewController.h
//  Mobile-Banking
//
//  Created by Nathan Jones on 5/15/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisteredLoginViewController : UITableViewController

@property(nonatomic,strong) NSString *pin;

@end