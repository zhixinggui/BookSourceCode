//
//  GetAccountsOperation.h
//  Mobile-Banking
//
//  Created by Nathan Jones on 3/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BaseOperation.h"

@interface GetAccountsOperation : BaseOperation

@end