//
//  LLNNetworkingResult.m
//  Low-Level Networking
//
//  Copyright (c) 2012 John Szumski. All rights reserved.
//

#import "LLNNetworkingResult.h"

@implementation LLNNetworkingResult

@synthesize temperatureCoil, temperatureOutlet, temperatureRoom, statusAirSwitchOn, statusAlarmActive, statusAuxilaryHeatOn, statusCompressorOn, statusFrontDoorOpen, statusSystemStandby;

@end