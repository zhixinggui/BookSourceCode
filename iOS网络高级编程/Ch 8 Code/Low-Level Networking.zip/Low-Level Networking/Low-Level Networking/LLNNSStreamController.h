//
//  LLNNSStreamController.h
//  Low-Level Networking
//
//  Copyright (c) 2012 John Szumski. All rights reserved.
//

#import "LLNNetworkingController.h"

@interface LLNNSStreamController : LLNNetworkingController <NSStreamDelegate>

@end