//
//  LLNCFNetworkController.h
//  Low-Level Networking
//
//  Copyright (c) 2012 John Szumski. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LLNNetworkingController.h"

@interface LLNCFNetworkController : LLNNetworkingController

@end