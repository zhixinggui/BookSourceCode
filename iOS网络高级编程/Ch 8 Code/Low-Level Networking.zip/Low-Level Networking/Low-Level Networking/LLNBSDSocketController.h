//
//  LLNBSDSocketController.h
//  Low-Level Networking
//
//  Copyright (c) 2012 John Szumski. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LLNViewController.h"

@interface LLNBSDSocketController : LLNNetworkingController

@end