//
//  FetchPostTweetsOperation.h
//  topstories
//
//  Created by Nathan Jones on 5/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BaseOperation.h"

@interface FetchPostTweetsOperation : BaseOperation

@property(nonatomic,strong) Post *post;

@end