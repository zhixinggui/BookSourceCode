//
//  FetchTopStoriesOperation.h
//  topstories
//
//  Created by Nathan Jones on 5/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BaseOperation.h"
#import "TopStoriesParser.h"

@interface FetchTopStoriesOperation : BaseOperation <TopStoriesDelegate>

@end