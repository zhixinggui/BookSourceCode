//
//  BIDHeaderCell.h
//  DialogViewer
//
//  Created by JN on 10/18/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "BIDContentCell.h"

@interface BIDHeaderCell : BIDContentCell

@end
