//
//  BIDViewController.h
//  TouchExplorer
//
//  Created by JN on 2013-12-19.
//  Copyright (c) 2013 apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController

@end
