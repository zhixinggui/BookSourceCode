//
//  SwapTests.m
//  SwapTests
//
//  Created by JN on 8/23/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface SwapTests : XCTestCase

@end

@implementation SwapTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
