//
//  BIDViewController.h
//  TextShooter
//

//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@interface BIDViewController : UIViewController

@end
