//
//  BIDYellowViewController.h
//  View Switcher
//
//  Created by JN on 8/28/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDYellowViewController : UIViewController

@end
