//
//  BIDBallView.h
//  Ball
//
//  Created by JN on 2014-1-16.
//  Copyright (c) 2014 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>

@interface BIDBallView : UIView

@property (assign, nonatomic) CMAcceleration acceleration;

@end
