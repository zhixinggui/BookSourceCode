//
//  Hello_WorldTests.m
//  Hello WorldTests
//
//  Created by Jack on 6/23/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Hello_WorldTests : XCTestCase

@end

@implementation Hello_WorldTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
