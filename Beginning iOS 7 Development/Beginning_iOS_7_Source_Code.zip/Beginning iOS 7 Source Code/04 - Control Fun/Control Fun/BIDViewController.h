//
//  BIDViewController.h
//  Control Fun
//
//  Created by JN on 9/25/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController <UIActionSheetDelegate>

- (IBAction)textFieldDoneEditing:(id)sender;

@end
