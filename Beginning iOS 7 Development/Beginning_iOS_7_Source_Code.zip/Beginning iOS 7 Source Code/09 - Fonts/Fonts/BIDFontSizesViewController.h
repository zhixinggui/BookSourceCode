//
//  BIDFontSizesViewController.h
//  Fonts
//
//  Created by JN on 2014-2-10.
//  Copyright (c) 2014 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDFontSizesViewController : UITableViewController

@property (strong, nonatomic) UIFont *font;

@end
