//
//  BIDAppDelegate.h
//  WhereAmI
//
//  Created by JN on 2014-1-10.
//  Copyright (c) 2014 apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
