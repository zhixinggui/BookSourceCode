//
//  BIDCheckMarkRecognizer.h
//  CheckPlease
//
//  Created by JN on 2013-12-20.
//  Copyright (c) 2013 apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDCheckMarkRecognizer : UIGestureRecognizer

@end
